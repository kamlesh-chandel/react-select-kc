import { default as UniversalSelect } from './UniversalSelect';
export default UniversalSelect;
export * from './UniversalSelect';
